// Cloudflare Worker: CFCBASE admin/config authority.
//
// Manual deploy only. This file does not read Cloudflare credentials,
// does not deploy itself, and does not call Anthropic models.
//
// Purpose:
// - Replace Cocodem's remote CFC route contract with a user-owned worker.
// - Let the extension receive CFC admin/config state without Anthropic login.
// - Keep model traffic local/custom only through the configured local proxy.

const EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn";
const LOCAL_BASE = "http://localhost:8520/";
const USER_UUID = "ac507011-00b5-56c4-b3ec-ad820dbafbc1";
const ORG_UUID = "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Private-Network": "true",
  "Access-Control-Max-Age": "86400",
  "Cache-Control": "no-store",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

function html(body, status = 200) {
  return new Response(body, {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "text/html; charset=utf-8" },
  });
}

function localToken() {
  const header = btoa(JSON.stringify({ alg: "none", typ: "JWT" }));
  const payload = btoa(JSON.stringify({
    iss: "cfc",
    sub: USER_UUID,
    exp: 4102444800,
    iat: 1700000000,
    localModelsOnly: true,
  }));
  return `${header}.${payload}.local`;
}

function profile() {
  const account = {
    uuid: USER_UUID,
    id: USER_UUID,
    account_uuid: USER_UUID,
    email_address: "user@local",
    email: "user@local",
    full_name: "Local User",
    name: "Local User",
    display_name: "Local User",
    has_password: true,
    has_completed_onboarding: true,
    preferred_language: "en-US",
    has_claude_pro: true,
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
    settings: { theme: "system", language: "en-US" },
  };
  const organization = {
    uuid: ORG_UUID,
    id: ORG_UUID,
    name: "Local CFC",
    role: "admin",
    organization_type: "personal",
    billing_type: "self_serve",
    capabilities: ["chat", "api", "computer_use", "claude_for_chrome"],
    rate_limit_tier: "local",
    settings: {},
    created_at: "2024-01-01T00:00:00Z",
  };
  return {
    ...account,
    account,
    organization,
    organizations: [organization],
    memberships: [{ organization, role: "admin", joined_at: "2024-01-01T00:00:00Z" }],
    active_organization_uuid: ORG_UUID,
  };
}

function bootstrap() {
  return {
    ...profile(),
    account_uuid: USER_UUID,
    statsig: {
      user: { userID: USER_UUID, custom: { organization_uuid: ORG_UUID } },
      values: { feature_gates: {}, dynamic_configs: {}, layer_configs: {} },
    },
    flags: {},
    features: [],
    active_flags: {},
    active_subscription: {
      plan: "local_cfc",
      status: "active",
      type: "local_cfc",
      billing_period: "none",
      current_period_start: "2024-01-01T00:00:00Z",
      current_period_end: "2099-12-31T23:59:59Z",
    },
    chat_enabled: true,
    capabilities: ["chat", "api", "computer_use", "claude_for_chrome"],
    rate_limit_tier: "local",
  };
}

function optionsPayload(requestUrl) {
  const origin = new URL(requestUrl).origin + "/";
  return {
    mode: "",
    cfcBase: origin,
    remoteCfcBase: origin,
    anthropicBaseUrl: "",
    apiBaseUrl: "http://127.0.0.1:1234/v1",
    apiKey: "",
    authToken: "",
    identity: {
      email: "user@local",
      username: "local-user",
      licenseKey: "",
    },
    apiBaseIncludes: ["https://api.anthropic.com/v1/"],
    proxyIncludes: [
      "https://api.anthropic.com/v1/",
      "https://api.anthropic.com/api/oauth/profile",
      "https://api.anthropic.com/api/bootstrap",
      "https://console.anthropic.com/v1/oauth/token",
      "https://platform.claude.com/v1/oauth/token",
      "https://api.anthropic.com/api/oauth/account",
      "https://api.anthropic.com/api/oauth/organizations",
      "https://api.anthropic.com/api/oauth/chat_conversations",
      "/api/web/domain_info/browser_extension",
    ],
    discardIncludes: [
      "cdn.segment.com",
      "api.segment.io",
      "events.statsigapi.net",
      "api.honeycomb.io",
      "prodregistryv2.org",
      "*ingest.us.sentry.io",
      "browser-intake-us5-datadoghq.com",
    ],
    modelAlias: {},
    ui: {},
    uiNodes: [
      {
        selector: { type: "button", props: { children: "API KEY ↗" } },
        replace: backendSettingsNode(origin),
      },
      {
        selector: { type: "button", props: { children: "API KEY" } },
        replace: backendSettingsNode(origin),
      },
      {
        selector: { type: "a", props: { children: "API KEY ↗" } },
        replace: backendSettingsNode(origin),
      },
      {
        selector: { type: "a", props: { children: "API KEY" } },
        replace: backendSettingsNode(origin),
      },
    ],
    blockAnalytics: true,
  };
}

function backendSettingsNode(origin) {
  return {
    type: "a",
    props: {
      href: origin + "backend_settings",
      target: "_blank",
      rel: "noreferrer",
      children: "Backend Settings ↗",
    },
  };
}

function authGate(url) {
  const redirectUri = url.searchParams.get("redirect_uri") || "";
  const state = url.searchParams.get("state") || "";
  const next = new URL("/oauth/redirect", url.origin);
  if (redirectUri) next.searchParams.set("redirect_uri", redirectUri);
  if (state) next.searchParams.set("state", state);
  next.searchParams.set("code", "cfc-local-" + Date.now());

  return html(`<!doctype html>
<html><head><meta charset="utf-8"><title>Claude in Chrome</title>
<style>
body{background:#f9f8f3;color:#1d1b16;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center}
.box{background:white;border:1px solid #e5e2d9;border-radius:32px;padding:40px;max-width:430px;width:100%;text-align:center;box-shadow:0 12px 40px rgba(0,0,0,.04)}
h1{font-family:Georgia,serif;font-weight:400;margin:0 0 10px;font-size:28px}
p{color:#6b6651;font-size:14px;line-height:1.5;margin:0 0 24px}
button{height:44px;padding:0 24px;background:#c45f3d;color:white;border:0;border-radius:12px;font-size:15px;font-weight:800;cursor:pointer}
</style></head><body><div class="box">
<h1>Claude in Chrome</h1>
<p>CFCBASE admin/config mode is ready. Model traffic remains local/custom only.</p>
<button onclick="location.href=${JSON.stringify(next.toString())}">Enter / Skip</button>
</div></body></html>`);
}

function redirectPage(url) {
  const redirectUri = url.searchParams.get("redirect_uri") || "";
  const state = url.searchParams.get("state") || "";
  const code = url.searchParams.get("code") || ("cfc-local-" + Date.now());
  const token = localToken();
  const storage = {
    accessToken: token,
    refreshToken: "local-refresh",
    tokenExpiry: Date.now() + 31536000000,
    accountUuid: USER_UUID,
    sidepanelToken: code,
    sidepanelTokenExpiry: Date.now() + 31536000000,
    ANTHROPIC_BASE_URL: "http://127.0.0.1:1234/v1",
    ANTHROPIC_API_KEY: "",
    ANTHROPIC_AUTH_TOKEN: "",
    email: "user@local",
    username: "local-user",
    licenseKey: "",
    hijackSettings: {
      backendUrl: "http://127.0.0.1:1234/v1",
      modelAliases: {},
      blockAnalytics: true,
    },
  };

  let finalUri = redirectUri;
  if (finalUri) {
    try {
      const u = new URL(finalUri);
      u.searchParams.set("code", code);
      if (state) u.searchParams.set("state", state);
      finalUri = u.toString();
    } catch (_) {}
  }

  return html(`<!doctype html>
<html><head><meta charset="utf-8"><title>Signed In</title>
<style>
body{background:#f9f8f3;color:#1d1b16;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center}
.box{background:white;border:1px solid #e5e2d9;border-radius:32px;padding:40px;max-width:520px;width:100%;text-align:center;box-shadow:0 12px 40px rgba(0,0,0,.04)}
h1{font-family:Georgia,serif;font-weight:400;margin:0 0 10px;font-size:28px}
p{color:#6b6651;font-size:14px;line-height:1.5;margin:0 0 12px}
</style></head><body><div class="box">
<h1>Signed in successfully!</h1>
<p id="msg">Writing CFCBASE admin state to the extension...</p>
</div>
<script>
(function(){
  const extensionId = ${JSON.stringify(EXTENSION_ID)};
  const storage = ${JSON.stringify(storage)};
  const finalUri = ${JSON.stringify(finalUri)};
  const msg = document.getElementById("msg");
  function done(text) {
    msg.textContent = text;
    if (finalUri) setTimeout(function(){ location.href = finalUri; }, 350);
  }
  try {
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage(extensionId, { type: "_set_storage_local", data: storage }, function() {
        if (chrome.runtime.lastError) {
          msg.textContent = "CFCBASE storage write failed: " + chrome.runtime.lastError.message;
          return;
        }
        done("CFCBASE admin state written. Opening sidepanel...");
      });
    } else {
      msg.textContent = "Chrome extension messaging is unavailable on this page.";
    }
  } catch (e) {
    msg.textContent = "CFCBASE storage write failed: " + e.message;
  }
})();
</script></body></html>`);
}

function backendSettings() {
  return html(`<!doctype html>
<html><head><meta charset="utf-8"><title>Backend Settings</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#19182c;color:#f5f3ee;margin:0;padding:32px 20px;min-height:100vh}
.wrap{max-width:900px;margin:0 auto}.panel{background:#142447;border:1px solid #20345f;border-radius:12px;padding:22px;margin:18px auto;max-width:760px}
h1,h2{color:#ff4568}.grid{display:grid;grid-template-columns:160px 1fr;gap:12px;align-items:center;margin:10px 0}
input,textarea{width:100%;background:#17172b;color:#f5f3ee;border:1px solid #ef4565;border-radius:6px;padding:11px;font-size:14px;font-family:monospace}
button{background:#ef4565;color:white;border:0;border-radius:6px;padding:12px 16px;font-weight:700;cursor:pointer}
code{background:#0f1a32;color:#7ff0b2;border-radius:4px;padding:2px 5px}
</style></head><body><div class="wrap">
<h1>OpenClaw -- Backend Setup</h1>
<section class="panel">
<h2>API Backend</h2>
<div class="grid"><label>Base URL</label><input id="base" value="http://127.0.0.1:1234/v1"></div>
<div class="grid"><label>API Key</label><input id="key" value=""></div>
<button onclick="localStorage.setItem('apiBaseUrl',document.getElementById('base').value)">Save Local Backend</button>
</section>
<section class="panel">
<h2>CFCBASE Contract</h2>
<p><code>/api/options</code> supplies exact API KEY replacement only.</p>
<p><code>/v1/*</code> remains local/custom backend only.</p>
</section>
</div></body></html>`);
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;
    const raw = request.url.toLowerCase();

    if (request.method === "OPTIONS") return new Response(null, { status: 200, headers: CORS_HEADERS });

    if (path === "/" || path === "/backend_settings") return backendSettings();
    if (path === "/api/options") return json(optionsPayload(request.url));
    if (path.includes("/oauth/authorize")) return authGate(url);
    if (path.includes("/oauth/redirect")) return redirectPage(url);
    if (raw.includes("oauth/token")) return json({ ...TOKEN_CACHE });
    if (raw.includes("oauth/profile") || raw.endsWith("/profile")) return json(profile());
    if (raw.includes("oauth/account") || raw.endsWith("/account")) return json(profile());
    if (raw.includes("bootstrap")) return json(bootstrap());
    if (raw.includes("organizations")) return json([profile().organization]);
    if (raw.includes("chat_conversations")) return json({ conversations: [], limit: 0, has_more: false, cursor: null });
    if (raw.includes("licenses/verify")) return json({ valid: true, license: "local", tier: "local", expires: "2099-12-31" });
    if (raw.includes("domain_info")) return json({ domain: "local", allowed: true });
    if (raw.includes("url_hash_check")) return json({ allowed: true });
    if (DISCARD_INCLUDES.some((item) => raw.includes(item.replace("*", "")))) return new Response(null, { status: 204, headers: CORS_HEADERS });

    return json({ ok: true, path });
  },
};
