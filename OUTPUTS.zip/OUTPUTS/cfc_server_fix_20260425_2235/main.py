#!/usr/bin/env python3
"""
Server-only replacement CFC proxy.

This file is intentionally only the server side:
- remote Cloudflare workers.dev face: https://myworker.mahnikka.workers.dev/
- local CFC server: http://localhost:8520/

The Worker redirects to this local server. This server answers the CFC contract
that the extension expects. It does not collect credentials and the OAuth page
is a one-button skip/enter flow.
"""

import base64
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler
from socketserver import TCPServer, ThreadingMixIn
from urllib.parse import parse_qs, quote, unquote, urlparse


REMOTE_CFC_BASE = os.environ.get("CFC_REMOTE_BASE", "https://myworker.mahnikka.workers.dev/").rstrip("/") + "/"
LOCAL_CFC_PORT = int(os.environ.get("CFC_PORT", "8520"))
LOCAL_CFC_BASE = f"http://localhost:{LOCAL_CFC_PORT}/"
DEFAULT_BACKEND_URL = os.environ.get("CFC_BACKEND_URL", "http://127.0.0.1:1234/v1").rstrip("/")

EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn"
ACCOUNT_UUID = "ac507011-00b5-56c4-b3ec-ad820dbafbc1"
ORG_UUID = "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08"
EMAIL = "free@claudeagent.ai"

OAUTH_SCOPES = "user:profile user:inference user:chat"


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def make_token() -> str:
    header = b64url(json.dumps({"alg": "none", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = b64url(json.dumps({
        "iss": "cfc",
        "sub": ACCOUNT_UUID,
        "aud": "claude-for-chrome",
        "email": EMAIL,
        "org": ORG_UUID,
        "scope": OAUTH_SCOPES,
        "iat": 1700000000,
        "exp": 9999999999,
    }, separators=(",", ":")).encode())
    return f"{header}.{payload}.local"


ACCESS_TOKEN = make_token()
REFRESH_TOKEN = ACCESS_TOKEN


LOCAL_ACCOUNT = {
    "uuid": ACCOUNT_UUID,
    "id": ACCOUNT_UUID,
    "email": EMAIL,
    "email_address": EMAIL,
    "full_name": "Local User",
    "name": "Local User",
    "display_name": "Local User",
    "has_password": True,
    "has_completed_onboarding": True,
    "preferred_language": "en-US",
    "has_claude_pro": True,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
    "settings": {"theme": "system", "language": "en-US"},
}

LOCAL_ORG = {
    "uuid": ORG_UUID,
    "id": ORG_UUID,
    "name": "Local",
    "role": "admin",
    "organization_type": "personal",
    "billing_type": "self_serve",
    "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
    "rate_limit_tier": "default_claude_pro",
    "settings": {},
    "created_at": "2024-01-01T00:00:00Z",
}

LOCAL_PROFILE = {
    **LOCAL_ACCOUNT,
    "account": LOCAL_ACCOUNT,
    "organization": LOCAL_ORG,
    "organizations": [LOCAL_ORG],
    "memberships": [{"organization": LOCAL_ORG, "role": "admin", "joined_at": "2024-01-01T00:00:00Z"}],
    "active_organization_uuid": ORG_UUID,
}

LOCAL_BOOTSTRAP = {
    **LOCAL_PROFILE,
    "account_uuid": ACCOUNT_UUID,
    "statsig": {
        "user": {"userID": ACCOUNT_UUID, "custom": {"organization_uuid": ORG_UUID}},
        "values": {"feature_gates": {}, "dynamic_configs": {}, "layer_configs": {}},
    },
    "flags": {},
    "features": [],
    "active_flags": {},
    "active_subscription": {
        "plan": "claude_pro",
        "status": "active",
        "type": "claude_pro",
        "billing_period": "monthly",
        "current_period_start": "2024-01-01T00:00:00Z",
        "current_period_end": "2099-12-31T23:59:59Z",
    },
    "has_claude_pro": True,
    "chat_enabled": True,
    "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
    "rate_limit_tier": "default_claude_pro",
    "settings": {"theme": "system", "language": "en-US"},
}


def options_response() -> dict:
    return {
        "mode": "",
        "cfcBase": REMOTE_CFC_BASE,
        "anthropicBaseUrl": "",
        "apiBaseIncludes": ["https://api.anthropic.com/v1/"],
        "proxyIncludes": [
            "cdn.segment.com",
            "featureassets.org",
            "assetsconfigcdn.org",
            "featuregates.org",
            "api.segment.io",
            "prodregistryv2.org",
            "beyondwickedmapping.org",
            "api.honeycomb.io",
            "statsigapi.net",
            "events.statsigapi.net",
            "api.statsigcdn.com",
            "*ingest.us.sentry.io",
            "https://api.anthropic.com/v1/",
            "https://api.anthropic.com/api/oauth/profile",
            "https://api.anthropic.com/api/bootstrap",
            "https://console.anthropic.com/v1/oauth/token",
            "https://platform.claude.com/v1/oauth/token",
            "https://api.anthropic.com/api/oauth/account",
            "https://api.anthropic.com/api/oauth/organizations",
            "https://api.anthropic.com/api/oauth/chat_conversations",
            "/api/web/domain_info/browser_extension",
            "/api/web/url_hash_check/browser_extension",
        ],
        "discardIncludes": [
            "cdn.segment.com",
            "api.segment.io",
            "events.statsigapi.net",
            "api.honeycomb.io",
            "prodregistryv2.org",
            "*ingest.us.sentry.io",
            "browser-intake-us5-datadoghq.com",
            "fpjs.dev",
            "openfpcdn.io",
            "api.fpjs.io",
            "googletagmanager.com",
        ],
        "modelAlias": {},
        "ui": {},
        "uiNodes": [],
    }


def token_response() -> dict:
    return {
        "access_token": ACCESS_TOKEN,
        "refresh_token": REFRESH_TOKEN,
        "token_type": "bearer",
        "expires_in": 315360000,
        "scope": OAUTH_SCOPES,
    }


def local_auth(path: str) -> dict:
    if "/mcp/v2/bootstrap" in path:
        return {"servers": [], "tools": [], "enabled": False}
    if "/spotlight" in path:
        return {"items": [], "total": 0}
    if "/features/" in path:
        return {"enabled": True, "features": {}}
    if "/oauth/account/settings" in path:
        return {"settings": {"theme": "system", "language": "en-US"}}
    if "/oauth/profile" in path:
        return LOCAL_PROFILE
    if "/oauth/account" in path:
        return LOCAL_PROFILE
    if "/oauth/token" in path or "/v1/oauth/token" in path:
        return token_response()
    if "/bootstrap" in path:
        return LOCAL_BOOTSTRAP
    if "/oauth/organizations" in path:
        tail = path.split("/oauth/organizations/", 1)[1] if "/oauth/organizations/" in path else ""
        if "/" in tail:
            return {}
        if tail:
            return LOCAL_ORG
        return [LOCAL_ORG]
    if "/chat_conversations" in path:
        return {"conversations": [], "limit": 0, "has_more": False, "cursor": None}
    if "/domain_info" in path:
        return {"allowed": True}
    if "/url_hash_check" in path:
        return {"allowed": True}
    if "/licenses/verify" in path:
        return {"valid": True, "ok": True, "status": "active", "email": EMAIL}
    if "/usage" in path:
        return {"usage": []}
    if "/entitlements" in path:
        return {"entitlements": []}
    if "/flags" in path:
        return {}
    return {}


def cors_headers() -> dict:
    return {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
        "Access-Control-Allow-Headers": "*",
        "Access-Control-Max-Age": "86400",
        "Cache-Control": "no-store",
    }


def oauth_page(query: str) -> bytes:
    params = parse_qs(query)
    redirect_uri = params.get("redirect_uri", [""])[0]
    state = params.get("state", [""])[0]
    escaped_redirect = json.dumps(redirect_uri)
    escaped_state = json.dumps(state)
    html = f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Continue</title>
  <style>
    body {{ margin:0; min-height:100vh; display:grid; place-items:center; font-family:system-ui,sans-serif; background:#111827; color:#f9fafb; }}
    main {{ width:min(420px,calc(100vw - 32px)); border:1px solid #374151; border-radius:8px; padding:24px; background:#1f2937; }}
    h1 {{ margin:0 0 8px; font-size:22px; }}
    p {{ color:#d1d5db; line-height:1.45; }}
    button {{ width:100%; padding:12px 14px; border:0; border-radius:6px; background:#2563eb; color:white; font-weight:700; cursor:pointer; }}
  </style>
</head>
<body>
  <main>
    <h1>Claude for Chrome</h1>
    <p>Local replacement CFC server is ready. No login, license, email, or API key is required.</p>
    <button id="enter">Enter</button>
  </main>
  <script>
    const redirectUri = {escaped_redirect};
    const state = {escaped_state};
    document.getElementById("enter").addEventListener("click", () => {{
      const bytes = new Uint8Array(24);
      crypto.getRandomValues(bytes);
      const raw = Array.from(bytes, b => String.fromCharCode(b)).join("");
      const code = "cfc-" + btoa(raw).replace(/\\+/g, "-").replace(/\\//g, "_").replace(/=/g, "");
      if (redirectUri) {{
        const u = new URL(redirectUri);
        u.searchParams.set("code", code);
        if (state) u.searchParams.set("state", state);
        location.href = u.href;
      }} else {{
        location.href = "/oauth/redirect?code=" + encodeURIComponent(code) + (state ? "&state=" + encodeURIComponent(state) : "");
      }}
    }});
  </script>
</body>
</html>"""
    return html.encode("utf-8")


def redirect_page(query: str) -> bytes:
    params = parse_qs(query)
    code = params.get("code", [""])[0] or "cfc-" + secrets.token_urlsafe(24)
    state = params.get("state", [""])[0]
    location = f"chrome-extension://{EXTENSION_ID}/oauth_callback.html?code={quote(code)}"
    if state:
        location += "&state=" + quote(state)
    html = f"""<!doctype html>
<html>
<head><meta charset="utf-8"><title>Complete</title></head>
<body>
<script>
location.replace({json.dumps(location)});
</script>
</body>
</html>"""
    return html.encode("utf-8")


def normalize_proxy_path(path: str) -> str:
    p = unquote(path)
    if p.startswith("/https:/") and not p.startswith("/https://"):
        p = p.replace("/https:/", "/https://", 1)
    if p.startswith("/http:/") and not p.startswith("/http://"):
        p = p.replace("/http:/", "/http://", 1)
    return p


def is_telemetry(path: str) -> bool:
    low = path.lower()
    return any(x in low for x in [
        "segment.com",
        "statsig",
        "honeycomb",
        "sentry.io",
        "datadoghq",
        "featureassets",
        "assetsconfigcdn",
        "featuregates",
        "prodregistryv2",
        "beyondwickedmapping",
        "fpjs.dev",
        "openfpcdn.io",
        "api.fpjs.io",
        "googletagmanager",
    ])


def is_v1(path: str) -> bool:
    p = normalize_proxy_path(path)
    return p.startswith("/v1/") or "/v1/" in p or "api.anthropic.com/v1/" in p


def v1_suffix(path: str) -> str:
    p = normalize_proxy_path(path)
    idx = p.find("/v1/")
    if idx >= 0:
        return p[idx + 3:]
    if p.startswith("/v1"):
        return p[3:]
    return p


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stdout.write("[CFC] " + fmt % args + "\n")
        sys.stdout.flush()

    def send_common_headers(self, content_type: str, length: int | None = None, status: int = 200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.send_header("Connection", "close")
        for key, value in cors_headers().items():
            self.send_header(key, value)
        self.end_headers()

    def send_json(self, obj, status: int = 200):
        data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
        self.send_common_headers("application/json", len(data), status)
        self.wfile.write(data)

    def send_html(self, data: bytes, status: int = 200):
        self.send_common_headers("text/html; charset=utf-8", len(data), status)
        self.wfile.write(data)

    def send_text(self, text: str, status: int = 200):
        data = text.encode("utf-8")
        self.send_common_headers("text/plain; charset=utf-8", len(data), status)
        self.wfile.write(data)

    def send_204(self):
        self.send_response(204)
        self.send_header("Connection", "close")
        for key, value in cors_headers().items():
            self.send_header(key, value)
        self.end_headers()

    def redirect(self, location: str, status: int = 302):
        self.send_response(status)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.send_header("Connection", "close")
        for key, value in cors_headers().items():
            self.send_header(key, value)
        self.end_headers()

    def do_OPTIONS(self):
        self.send_204()

    def do_GET(self):
        self.route("GET", b"")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(length) if length else b""
        self.route("POST", body)

    def do_PUT(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(length) if length else b""
        self.route("PUT", body)

    def do_PATCH(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(length) if length else b""
        self.route("PATCH", body)

    def do_DELETE(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(length) if length else b""
        self.route("DELETE", body)

    def route(self, method: str, body: bytes):
        parsed = urlparse(self.path)
        path = normalize_proxy_path(parsed.path)
        full_path = normalize_proxy_path(self.path)

        if is_telemetry(full_path):
            self.send_204()
            return

        if path == "/" or path == "":
            self.send_html(f"""<!doctype html>
<html><head><meta charset="utf-8"><title>CFC</title></head>
<body>
<h1>Local CFC server running</h1>
<p>Remote: {REMOTE_CFC_BASE}</p>
<p>Local: {LOCAL_CFC_BASE}</p>
<p><a href="/api/options">/api/options</a></p>
</body></html>""".encode("utf-8"))
            return

        if path.startswith("/api/options"):
            self.send_json(options_response())
            return

        if "/oauth/authorize" in full_path:
            self.send_html(oauth_page(parsed.query))
            return

        if path.startswith("/oauth/redirect"):
            self.send_html(redirect_page(parsed.query))
            return

        if path.startswith("/discard"):
            self.send_204()
            return

        if is_v1(full_path):
            self.forward_v1(method, body)
            return

        if self.is_auth_path(full_path):
            self.send_json(local_auth(full_path))
            return

        self.send_json({"ok": True, "path": self.path})

    def is_auth_path(self, path: str) -> bool:
        return any(x in path for x in [
            "/oauth/",
            "/bootstrap",
            "/domain_info",
            "/url_hash_check",
            "/chat_conversations",
            "/organizations",
            "/api/web/",
            "/features/",
            "/spotlight",
            "/usage",
            "/entitlements",
            "/flags",
            "/mcp/v2/",
            "/licenses/",
            "/chrome-extension://",
            "/https://api.anthropic.com/api/",
            "/https://console.anthropic.com/v1/oauth/token",
            "/https://platform.claude.com/v1/oauth/token",
        ])

    def forward_v1(self, method: str, body: bytes):
        suffix = v1_suffix(self.path)
        target = DEFAULT_BACKEND_URL + suffix

        headers = {}
        for key, value in self.headers.items():
            lk = key.lower()
            if lk in {
                "content-type",
                "accept",
                "authorization",
                "anthropic-version",
                "anthropic-beta",
                "anthropic-client-platform",
                "anthropic-client-version",
                "x-api-key",
            }:
                headers[key] = value
        headers.setdefault("anthropic-client-platform", "claude_browser_extension")

        req = urllib.request.Request(target, data=body or None, headers=headers, method=method)
        try:
            resp = urllib.request.urlopen(req, timeout=300)
            content_type = resp.headers.get("Content-Type", "application/json")
            self.send_response(resp.status)
            for key, value in cors_headers().items():
                self.send_header(key, value)
            self.send_header("Content-Type", content_type)
            self.send_header("Connection", "close")
            if "text/event-stream" in content_type:
                self.end_headers()
                while True:
                    chunk = resp.read(4096)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
            else:
                data = resp.read()
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            resp.close()
        except urllib.error.HTTPError as exc:
            data = exc.read() or b""
            self.send_response(exc.code)
            for key, value in cors_headers().items():
                self.send_header(key, value)
            self.send_header("Content-Type", exc.headers.get("Content-Type", "application/json"))
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
        except Exception as exc:
            self.send_json({"error": {"type": "proxy_error", "message": str(exc), "target": target}}, 502)


class Server(ThreadingMixIn, TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    print("Local replacement CFC server")
    print(f"Remote xyz replacement: {REMOTE_CFC_BASE}")
    print(f"Local 8787 replacement: {LOCAL_CFC_BASE}")
    print(f"Backend /v1 target: {DEFAULT_BACKEND_URL}")
    with Server(("127.0.0.1", LOCAL_CFC_PORT), Handler) as httpd:
        print(f"Listening on {LOCAL_CFC_BASE}")
        httpd.serve_forever()


if __name__ == "__main__":
    main()
