#!/usr/bin/env python3
"""
Complete standalone CFCBASE server.

No wrapper imports.
No request.js edits.
No existing file edits.

Contract:
  /api/options       returns the 12.py UI contract: ui={} and uiNodes=[]
  /backend_settings  serves the proxy/domain backend settings page
  /oauth/authorize   serves a local Enter / Skip gate
  /oauth/redirect    completes local test auth
  profile/account/bootstrap/org/license routes return JSON locally
  /v1/*              forwards to the configured local backend
  telemetry          is discarded locally
"""

import base64
import json
import mimetypes
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from socketserver import TCPServer, ThreadingMixIn


STAMP = "20260426_131900"
EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn"

SCRIPT_PATH = Path(__file__).resolve()
OUTPUTS_DIR = SCRIPT_PATH.parent
WORKSPACE_DIR = OUTPUTS_DIR.parent

LOCAL_HOST = os.environ.get("CFC_LOCAL_HOST", "localhost")
LOCAL_PORT = int(os.environ.get("CFC_LOCAL_PORT", "8520"))
LOCAL_BIND = os.environ.get("CFC_BIND_HOST", "127.0.0.1")
LOCAL_BASE = f"http://{LOCAL_HOST}:{LOCAL_PORT}/"

REMOTE_BASE = os.environ.get(
    "CFC_REMOTE_BASE",
    "https://myworker.mahnikka.workers.dev/",
).rstrip("/") + "/"

DEFAULT_BACKEND_URL = os.environ.get("CFC_DEFAULT_BACKEND_URL", "http://127.0.0.1:1234/v1")
BACKEND_SETTINGS_URL = LOCAL_BASE + "backend_settings"

STATE_IDENTITY_FILE = OUTPUTS_DIR / f"cfc_identity_complete_{STAMP}.json"
STATE_BACKENDS_FILE = OUTPUTS_DIR / f"cfc_backends_complete_{STAMP}.json"

USER_UUID = "ac507011-00b5-56c4-b3ec-ad820dbafbc1"
ORG_UUID = "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08"

GENERATED_EXTENSION_DIR = WORKSPACE_DIR / "claude-sanitized-20260425-212051"
GENERATED_ASSETS_DIR = GENERATED_EXTENSION_DIR / "assets"


TELEMETRY_MARKERS = [
    "segment.com",
    "api.segment.io",
    "statsig",
    "statsigapi.net",
    "honeycomb",
    "sentry",
    "datadoghq",
    "featureassets",
    "assetsconfigcdn",
    "featuregates",
    "prodregistryv2",
    "beyondwickedmapping",
    "fpjs.dev",
    "openfpcdn.io",
    "api.fpjs.io",
    "googletagmanager",
    "ddsource=browser",
]

PROXY_INCLUDES = [
    "https://api.anthropic.com/v1/",
    "https://api.anthropic.com/api/oauth/profile",
    "https://api.anthropic.com/api/bootstrap",
    "https://console.anthropic.com/v1/oauth/token",
    "https://platform.claude.com/v1/oauth/token",
    "https://api.anthropic.com/api/oauth/account",
    "https://api.anthropic.com/api/oauth/organizations",
    "https://api.anthropic.com/api/oauth/chat_conversations",
    "/api/web/domain_info/browser_extension",
    "/api/web/url_hash_check/browser_extension",
    "cdn.segment.com",
    "featureassets.org",
    "assetsconfigcdn.org",
    "featuregates.org",
    "api.segment.io",
    "prodregistryv2.org",
    "beyondwickedmapping.org",
    "api.honeycomb.io",
    "statsigapi.net",
    "events.statsigapi.net",
    "api.statsigcdn.com",
    "*ingest.us.sentry.io",
]

DISCARD_INCLUDES = [
    "cdn.segment.com",
    "api.segment.io",
    "events.statsigapi.net",
    "api.honeycomb.io",
    "prodregistryv2.org",
    "*ingest.us.sentry.io",
    "browser-intake-us5-datadoghq.com",
    "fpjs.dev",
    "openfpcdn.io",
    "api.fpjs.io",
    "googletagmanager.com",
]

DEFAULT_IDENTITY = {
    "apiBaseUrl": DEFAULT_BACKEND_URL,
    "apiKey": "",
    "authToken": "",
    "email": "user@local",
    "username": "local-user",
    "licenseKey": "",
    "blockAnalytics": True,
    "modelAliases": {},
    "mode": "",
}

DEFAULT_BACKENDS = [
    {
        "name": "Default",
        "url": DEFAULT_BACKEND_URL,
        "key": "",
        "models": [],
        "modelAlias": {},
        "enabled": True,
    }
]


def read_json(path, fallback):
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, type(fallback)):
                return data
        except Exception:
            pass
    return json.loads(json.dumps(fallback))


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


IDENTITY = read_json(STATE_IDENTITY_FILE, DEFAULT_IDENTITY)
BACKENDS = read_json(STATE_BACKENDS_FILE, DEFAULT_BACKENDS)


def b64url(obj):
    raw = json.dumps(obj, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


TOKEN_CACHE = {
    "access_token": b64url({"alg": "none", "typ": "JWT"})
    + "."
    + b64url({"iss": "cfc", "sub": USER_UUID, "exp": 4102444800, "iat": 1700000000})
    + ".local",
    "token_type": "bearer",
    "expires_in": 2147483647,
    "refresh_token": "local-refresh",
    "scope": "user:profile user:inference user:chat",
}


LOCAL_ORG = {
    "uuid": ORG_UUID,
    "id": ORG_UUID,
    "name": "Local",
    "role": "admin",
    "organization_type": "personal",
    "billing_type": "self_serve",
    "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
    "rate_limit_tier": "default_claude_pro",
    "settings": {},
    "created_at": "2024-01-01T00:00:00Z",
}


def account_payload():
    email = IDENTITY.get("email") or "user@local"
    name = IDENTITY.get("username") or "Local User"
    return {
        "uuid": USER_UUID,
        "id": USER_UUID,
        "account_uuid": USER_UUID,
        "email_address": email,
        "email": email,
        "full_name": name,
        "name": name,
        "display_name": name,
        "has_password": True,
        "has_completed_onboarding": True,
        "preferred_language": "en-US",
        "has_claude_pro": True,
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
        "settings": {"theme": "system", "language": "en-US"},
    }


def profile_payload():
    account = account_payload()
    return {
        **account,
        "account": account,
        "organization": LOCAL_ORG,
        "organizations": [LOCAL_ORG],
        "memberships": [
            {
                "organization": LOCAL_ORG,
                "role": "admin",
                "joined_at": "2024-01-01T00:00:00Z",
            }
        ],
        "active_organization_uuid": ORG_UUID,
    }


def bootstrap_payload():
    profile = profile_payload()
    return {
        **profile,
        "account_uuid": USER_UUID,
        "statsig": {
            "user": {"userID": USER_UUID, "custom": {"organization_uuid": ORG_UUID}},
            "values": {"feature_gates": {}, "dynamic_configs": {}, "layer_configs": {}},
        },
        "flags": {},
        "features": [],
        "active_flags": {},
        "active_subscription": {
            "plan": "claude_pro",
            "status": "active",
            "type": "claude_pro",
            "billing_period": "monthly",
            "current_period_start": "2024-01-01T00:00:00Z",
            "current_period_end": "2099-12-31T23:59:59Z",
        },
        "chat_enabled": True,
        "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
        "rate_limit_tier": "default_claude_pro",
    }


def auth_payload(raw_path):
    low = raw_path.lower()
    if "oauth/token" in low:
        return TOKEN_CACHE
    if "oauth/profile" in low or low.rstrip("/").endswith("/profile"):
        return profile_payload()
    if "oauth/account/settings" in low:
        return {"settings": {"theme": "system", "language": "en-US"}}
    if "oauth/account" in low or low.rstrip("/").endswith("/account"):
        return profile_payload()
    if "bootstrap" in low:
        return bootstrap_payload()
    if "oauth/organizations" in low or low.rstrip("/").endswith("/organizations"):
        return [LOCAL_ORG]
    if "chat_conversations" in low:
        return {"conversations": [], "limit": 0, "has_more": False, "cursor": None}
    if "domain_info" in low:
        return {"domain": "local", "allowed": True}
    if "url_hash_check" in low:
        return {"allowed": True}
    if "licenses/verify" in low:
        return {"valid": True, "license": "local", "tier": "pro", "expires": "2099-12-31"}
    if "mcp/v2/bootstrap" in low:
        return {"servers": [], "tools": [], "enabled": False}
    if "spotlight" in low:
        return {"items": [], "total": 0}
    if "features/" in low:
        return {"enabled": True, "features": {}}
    if "usage" in low:
        return {"usage": {}, "limit": None}
    if "entitlements" in low:
        return {"entitlements": []}
    if "flags" in low:
        return {}
    return None


def merged_aliases():
    out = {}
    if isinstance(IDENTITY.get("modelAliases"), dict):
        out.update(IDENTITY["modelAliases"])
    for backend in BACKENDS:
        aliases = backend.get("modelAlias") or {}
        if backend.get("enabled", True) and isinstance(aliases, dict):
            out.update(aliases)
    return out


def options_payload():
    discard = list(DISCARD_INCLUDES) if IDENTITY.get("blockAnalytics", True) else []
    return {
        "mode": IDENTITY.get("mode", "") or "",
        "cfcBase": LOCAL_BASE,
        "remoteCfcBase": REMOTE_BASE,
        "anthropicBaseUrl": "",
        "apiBaseUrl": IDENTITY.get("apiBaseUrl") or DEFAULT_BACKEND_URL,
        "apiKey": IDENTITY.get("apiKey", ""),
        "authToken": IDENTITY.get("authToken", ""),
        "identity": {
            "email": IDENTITY.get("email", "user@local"),
            "username": IDENTITY.get("username", "local-user"),
            "licenseKey": IDENTITY.get("licenseKey", ""),
        },
        "backends": BACKENDS,
        "apiBaseIncludes": ["https://api.anthropic.com/v1/"],
        "proxyIncludes": list(PROXY_INCLUDES),
        "discardIncludes": discard,
        "modelAlias": merged_aliases(),
        "ui": {},
        "uiNodes": [],
        "blockAnalytics": bool(IDENTITY.get("blockAnalytics", True)),
    }


def pick_backends(model):
    enabled = [b for b in BACKENDS if b.get("enabled", True)]
    exact = [b for b in enabled if b.get("models") and model in b.get("models", [])]
    catch_all = [b for b in enabled if not b.get("models")]
    preferred = exact or catch_all or enabled
    if not preferred:
        return []
    first = preferred[0]
    return [first] + [b for b in enabled if b is not first]


def html_shell(title, body, dark=False):
    if dark:
        css = """
        *{box-sizing:border-box}
        body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#19182c;color:#f5f3ee;margin:0;padding:32px 20px;min-height:100vh}
        .wrap{max-width:980px;margin:0 auto}
        h1{font-size:28px;color:#ff4568;margin:0 0 4px;font-weight:800}
        .sub{color:#8b8eb6;margin:0 0 28px}
        .panel{background:#142447;border:1px solid #20345f;border-radius:12px;padding:22px;margin:18px auto;max-width:760px}
        .panel h2{font-size:16px;color:#ff4568;margin:0 0 16px}
        .backend{border:1px dashed #243963;border-radius:10px;padding:14px;margin:10px 0;background:#121c36}
        .grid{display:grid;grid-template-columns:160px 1fr;gap:12px;align-items:center;margin:10px 0}
        label{color:#8b8eb6;font-size:14px}
        input,textarea,select{width:100%;background:#17172b;color:#f5f3ee;border:1px solid #ef4565;border-radius:6px;padding:11px;font-size:14px;font-family:monospace}
        .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
        button{background:#ef4565;color:white;border:0;border-radius:6px;padding:10px 16px;font-weight:700;cursor:pointer}
        button.secondary{background:#202842;color:#d8d7e8;border:1px solid #303b62}
        button.danger{background:#3a1730;color:#ff4568;border:1px solid #73304c}
        .save{display:block;max-width:760px;margin:18px auto 0;width:100%;font-size:18px;padding:16px;border-radius:8px}
        .status{display:none;margin:0 auto 16px;max-width:760px;padding:12px 16px;border-radius:8px;font-weight:700}
        .ok{display:block;background:#164f36;color:#9af0ba}
        .err{display:block;background:#4b1b2b;color:#ff9bb0}
        .arch{background:#17172b;border:1px solid #2b2a44;border-radius:8px;padding:14px;color:#8b8eb6;font-family:monospace;font-size:13px;line-height:1.7}
        code{background:#0f1a32;color:#7ff0b2;border-radius:4px;padding:2px 5px}
        """
    else:
        css = """
        *{box-sizing:border-box}
        body{background:#f9f8f3;color:#1d1b16;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
        .box{background:white;border:1px solid #e5e2d9;border-radius:32px;padding:40px;max-width:430px;width:100%;text-align:center;box-shadow:0 12px 40px rgba(0,0,0,.04)}
        .logo{width:72px;height:72px;border-radius:20px;border:1px solid #e5e2d9;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;color:#d97757;font-size:38px}
        h1{font-family:"Iowan Old Style",Georgia,serif;font-weight:400;margin:0 0 10px;font-size:28px}
        p{color:#6b6651;font-size:14px;line-height:1.5;margin:0 0 24px}
        button,.btn{height:44px;padding:0 24px;background:#c45f3d;color:white;border:0;border-radius:12px;font-size:15px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center}
        code{background:#f4f1ea;border-radius:5px;padding:2px 5px}
        """
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title}</title><style>{css}</style></head><body>{body}</body></html>"
    )


def backend_settings_html():
    data = json.dumps(BACKENDS)
    body = f"""
    <div class="wrap">
      <h1>OpenClaw -- Backend Setup</h1>
      <p class="sub">Configure backends - test connections - connect to extension</p>
      <div id="status" class="status"></div>
      <section class="panel">
        <h2>API Backends</h2>
        <div id="backendList"></div>
        <button class="secondary" onclick="addBackend()">+ Add Backend</button>
      </section>
      <section class="panel">
        <h2>Extension Routing</h2>
        <div class="grid"><label>cfcBase URL</label><input id="cfcBase" value="{LOCAL_BASE}"></div>
        <div class="grid"><label>apiBaseUrl</label><input id="apiBaseUrl" value="{IDENTITY.get('apiBaseUrl') or DEFAULT_BACKEND_URL}"></div>
        <div class="grid"><label>Mode</label><select id="mode"><option value="">api -- local / custom backend</option><option value="claude">claude -- official</option></select></div>
        <div class="grid"><label>Access Token</label><input id="authToken" value="{IDENTITY.get('authToken','')}" placeholder="optional"></div>
      </section>
      <section class="panel">
        <h2>Quick Actions</h2>
        <div class="actions">
          <button onclick="testAll()">Test All Backends</button>
          <button onclick="fetchModels()">Fetch All Models</button>
          <button class="secondary" onclick="resetDefaults()">Reset to Defaults</button>
          <button class="danger" onclick="clearData()">Clear Local Routing Data</button>
        </div>
      </section>
      <section class="panel">
        <h2>Architecture</h2>
        <div class="arch">
          <b>CFCBASE Local:</b> {LOCAL_BASE}<br>
          <b>CFCBASE Remote:</b> {REMOTE_BASE}<br>
          <b>Backend Default:</b> {DEFAULT_BACKEND_URL}<br><br>
          <code>/api/options</code> returns <code>ui: {{}}</code> and <code>uiNodes: []</code>.<br>
          Backend Settings is served by the proxy route only.
        </div>
      </section>
      <button class="save" onclick="saveConfig()">Save Config & Connect to Extension -></button>
    </div>
    <script>
    let backends = {data};
    function esc(s){{return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;")}}
    function status(msg, ok=true){{const el=document.getElementById("status");el.textContent=msg;el.className="status "+(ok?"ok":"err")}}
    function renderBackends(){{
      document.getElementById("backendList").innerHTML = backends.map((b,i)=>`<div class="backend">
        <div class="grid"><label>Name</label><input value="${{esc(b.name||"")}}" onchange="backends[${{i}}].name=this.value"></div>
        <div class="grid"><label>Base URL</label><input value="${{esc(b.url||"")}}" onchange="backends[${{i}}].url=this.value"></div>
        <div class="grid"><label>API Key</label><input type="password" value="${{esc(b.key||"")}}" onchange="backends[${{i}}].key=this.value"></div>
        <div class="grid"><label>Models</label><textarea onchange="backends[${{i}}].models=this.value.split(',').map(x=>x.trim()).filter(Boolean)">${{esc((b.models||[]).join(", "))}}</textarea></div>
        <div class="actions"><button class="secondary" onclick="testBackend(${{i}})">Test</button>${{backends.length>1?`<button class="danger" onclick="removeBackend(${{i}})">Remove</button>`:""}}</div>
        <div class="sub" id="backendStatus${{i}}"></div>
      </div>`).join("");
    }}
    function addBackend(){{backends.push({{name:"",url:"http://127.0.0.1:1234/v1",key:"",models:[],enabled:true,modelAlias:{{}}}});renderBackends()}}
    function removeBackend(i){{backends.splice(i,1);renderBackends()}}
    async function testBackend(i){{
      const b=backends[i], el=document.getElementById("backendStatus"+i);
      el.textContent="Testing...";
      try{{
        const headers=b.key?{{Authorization:"Bearer "+b.key}}:{{}};
        const r=await fetch((b.url||"").replace(/\\/v1\\/?$/,"")+"/v1/models",{{headers}});
        if(!r.ok) throw new Error("HTTP "+r.status);
        const d=await r.json();
        el.textContent="Connected! Models: "+((d.data||[]).map(m=>m.id).slice(0,5).join(", ")||"OK");
      }}catch(e){{el.textContent="Failed: "+e.message}}
    }}
    async function testAll(){{for(let i=0;i<backends.length;i++) await testBackend(i); status("Backend tests complete")}}
    async function fetchModels(){{await testAll()}}
    function resetDefaults(){{backends=[{{name:"Default",url:"http://127.0.0.1:1234/v1",key:"",models:[],enabled:true,modelAlias:{{}}}}];renderBackends();status("Defaults restored")}}
    function clearData(){{try{{localStorage.removeItem("apiBaseUrl")}}catch(e){{}};status("Local routing data cleared")}}
    async function saveConfig(){{
      const identity={{apiBaseUrl:document.getElementById("apiBaseUrl").value,authToken:document.getElementById("authToken").value,mode:document.getElementById("mode").value}};
      const br=await fetch("/api/backends",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{backends}})}});
      const ir=await fetch("/api/identity",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify(identity)}});
      try{{localStorage.setItem("apiBaseUrl",identity.apiBaseUrl)}}catch(e){{}}
      if(br.ok && ir.ok) status("Saved config to CFCBASE");
      else status("Save failed", false);
    }}
    renderBackends();
    </script>
    """
    return html_shell("Backend Settings", body, dark=True)


def auth_gate_html(query):
    params = urllib.parse.parse_qs(query, keep_blank_values=True)
    redirect_uri = params.get("redirect_uri", [""])[0]
    state = params.get("state", [""])[0]
    body = f"""
    <div class="box">
      <div class="logo">*</div>
      <h1>Claude in Chrome</h1>
      <p>Local CFC authentication is ready. No real login is required.</p>
      <button id="enter">Enter / Skip</button>
    </div>
    <script>
    document.getElementById("enter").onclick = () => {{
      const redirectUri = {json.dumps(redirect_uri)};
      const state = {json.dumps(state)};
      const code = "cfc-local-" + Date.now();
      if (redirectUri) {{
        const u = new URL(redirectUri);
        u.searchParams.set("code", code);
        if (state) u.searchParams.set("state", state);
        location.href = u.toString();
      }} else {{
        const u = new URL("{LOCAL_BASE}oauth/redirect");
        u.searchParams.set("code", code);
        location.href = u.toString();
      }}
    }};
    </script>
    """
    return html_shell("Local CFC Sign In", body, dark=False)


def redirect_html(query):
    params = urllib.parse.parse_qs(query, keep_blank_values=True)
    code = params.get("code", [f"cfc-local-{int(time.time())}"])[0]
    body = f"""
    <div class="box">
      <div class="logo">*</div>
      <h1>Signed in locally</h1>
      <p>Local code issued. No remote credentials were requested.</p>
      <p><code>{code}</code></p>
    </div>
    """
    return html_shell("Local CFC Redirect", body, dark=False)


class Handler(BaseHTTPRequestHandler):
    server_version = "CFCBASEComplete/20260426_131900"

    def log_message(self, fmt, *args):
        print(f"[{time.strftime('%H:%M:%S')}] {self.command} {self.path} - " + (fmt % args))

    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Cache-Control, Accept, Authorization, x-api-key, "
            "anthropic-version, anthropic-beta, anthropic-client-platform, "
            "anthropic-client-version, x-app, x-service-name",
        )
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")

    def send_bytes(self, data, content_type="application/octet-stream", status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def send_json(self, data, status=200):
        self.send_bytes(json.dumps(data).encode("utf-8"), "application/json", status)

    def send_html(self, html, status=200):
        self.send_bytes(html.encode("utf-8"), "text/html; charset=utf-8", status)

    def send_empty(self, status=204):
        self.send_response(status)
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()

    def read_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        return self.rfile.read(length) if length else b""

    def is_telemetry(self):
        low = self.path.lower()
        return any(marker in low for marker in TELEMETRY_MARKERS)

    def is_v1(self):
        low = self.path.lower()
        if "/v1/oauth" in low:
            return False
        return low.startswith("/v1/") or (
            "/v1/" in low and ("api.anthropic.com" in low or low.startswith("/https://api.anthropic.com/"))
        )

    def v1_suffix(self):
        if self.path.startswith("/v1/"):
            return self.path[3:]
        idx = self.path.find("/v1/")
        if idx >= 0:
            return self.path[idx + 3:]
        return self.path

    def serve_static(self, path):
        rel = path.lstrip("/").split("?", 1)[0]
        candidates = []
        if rel.startswith("assets/"):
            candidates.append(GENERATED_ASSETS_DIR / rel[len("assets/"):])
        candidates.append(GENERATED_EXTENSION_DIR / rel)
        for candidate in candidates:
            if candidate.exists() and candidate.is_file():
                content_type = mimetypes.guess_type(str(candidate))[0] or "application/octet-stream"
                if candidate.suffix == ".js":
                    content_type = "application/javascript; charset=utf-8"
                if candidate.suffix == ".css":
                    content_type = "text/css; charset=utf-8"
                self.send_bytes(candidate.read_bytes(), content_type)
                return True
        return False

    def forward_v1(self, method, body):
        model = ""
        if body:
            try:
                model = json.loads(body.decode("utf-8")).get("model", "")
            except Exception:
                model = ""
        suffix = self.v1_suffix()
        last_error = None
        allowed = {
            "content-type",
            "accept",
            "authorization",
            "anthropic-version",
            "anthropic-beta",
            "anthropic-client-platform",
            "anthropic-client-version",
            "x-api-key",
            "x-service-name",
        }
        base_headers = {k: v for k, v in self.headers.items() if k.lower() in allowed}
        for backend in pick_backends(model):
            target = backend.get("url", DEFAULT_BACKEND_URL).rstrip("/") + suffix
            headers = dict(base_headers)
            if backend.get("key"):
                headers["Authorization"] = "Bearer " + backend["key"]
            elif IDENTITY.get("apiKey"):
                headers["Authorization"] = "Bearer " + IDENTITY["apiKey"]
            send_body = body
            if send_body and method in ("POST", "PUT", "PATCH"):
                try:
                    parsed = json.loads(send_body.decode("utf-8"))
                    aliases = {**merged_aliases(), **(backend.get("modelAlias") or {})}
                    if parsed.get("model") in aliases:
                        parsed["model"] = aliases[parsed["model"]]
                        send_body = json.dumps(parsed).encode("utf-8")
                except Exception:
                    pass
            try:
                req = urllib.request.Request(target, data=send_body or None, headers=headers, method=method)
                resp = urllib.request.urlopen(req, timeout=300)
                data = resp.read()
                self.send_bytes(data, resp.headers.get("Content-Type") or "application/json", resp.status)
                return
            except urllib.error.HTTPError as exc:
                data = exc.read() or b""
                if exc.code < 500:
                    self.send_bytes(data, exc.headers.get("Content-Type") or "application/json", exc.code)
                    return
                last_error = f"HTTP {exc.code}"
            except Exception as exc:
                last_error = str(exc)
        self.send_json({"error": {"type": "proxy_error", "message": "All backends failed. Last: " + str(last_error)}}, 502)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        auth = auth_payload(self.path)
        if self.is_telemetry():
            self.send_empty(202)
            return
        if path == "/" or path == "":
            self.send_html(html_shell("CFCBASE", f"<div class='box'><h1>CFCBASE</h1><p>{LOCAL_BASE}</p><a class='btn' href='/backend_settings'>Backend Settings</a></div>", dark=False))
            return
        if path.startswith("/api/options"):
            self.send_json(options_payload())
            return
        if path.startswith("/api/identity"):
            self.send_json(IDENTITY)
            return
        if path.startswith("/api/backends"):
            self.send_json({"backends": BACKENDS})
            return
        if path.startswith("/api/arc-split-view"):
            self.send_json({"html": "<div id='cfc-arc'>Local CFC arc split view</div>"})
            return
        if path.startswith("/discard"):
            self.send_empty(204)
            return
        if path.startswith("/backend_settings"):
            self.send_html(backend_settings_html())
            return
        if path.startswith("/oauth/authorize"):
            self.send_html(auth_gate_html(parsed.query))
            return
        if path.startswith("/oauth/redirect"):
            self.send_html(redirect_html(parsed.query))
            return
        if auth is not None:
            self.send_json(auth)
            return
        if self.serve_static(path):
            return
        if self.is_v1():
            self.forward_v1("GET", b"")
            return
        self.send_json({"ok": True, "path": self.path})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        body = self.read_body()
        if self.is_telemetry():
            self.send_empty(202)
            return
        if path.startswith("/api/identity"):
            try:
                data = json.loads(body.decode("utf-8") or "{}")
                for key in ["apiBaseUrl", "apiKey", "authToken", "email", "username", "licenseKey", "blockAnalytics", "modelAliases", "mode"]:
                    if key in data:
                        IDENTITY[key] = data[key]
                if not isinstance(IDENTITY.get("modelAliases"), dict):
                    IDENTITY["modelAliases"] = {}
                write_json(STATE_IDENTITY_FILE, IDENTITY)
                self.send_json({"ok": True, "identity": IDENTITY})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400)
            return
        if path.startswith("/api/backends"):
            try:
                data = json.loads(body.decode("utf-8") or "{}")
                backends = data.get("backends")
                if not isinstance(backends, list) or not backends:
                    raise ValueError("backends must be a non-empty list")
                for backend in backends:
                    backend.setdefault("name", "")
                    backend.setdefault("url", DEFAULT_BACKEND_URL)
                    backend.setdefault("key", "")
                    backend.setdefault("models", [])
                    backend.setdefault("modelAlias", {})
                    backend.setdefault("enabled", True)
                BACKENDS[:] = backends
                write_json(STATE_BACKENDS_FILE, BACKENDS)
                self.send_json({"ok": True, "backends": BACKENDS})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400)
            return
        auth = auth_payload(self.path)
        if auth is not None:
            self.send_json(auth)
            return
        if self.is_v1():
            self.forward_v1("POST", body)
            return
        self.send_json({"ok": True})

    def do_PUT(self):
        body = self.read_body()
        auth = auth_payload(self.path)
        if auth is not None:
            self.send_json(auth)
            return
        if self.is_v1():
            self.forward_v1("PUT", body)
            return
        self.send_json({"ok": True})

    def do_PATCH(self):
        body = self.read_body()
        auth = auth_payload(self.path)
        if auth is not None:
            self.send_json(auth)
            return
        if self.is_v1():
            self.forward_v1("PATCH", body)
            return
        self.send_json({"ok": True})

    def do_DELETE(self):
        body = self.read_body()
        auth = auth_payload(self.path)
        if auth is not None:
            self.send_json(auth)
            return
        if self.is_v1():
            self.forward_v1("DELETE", body)
            return
        self.send_json({"ok": True})


class Server(ThreadingMixIn, TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    print("=" * 72)
    print("Complete standalone CFCBASE server")
    print("=" * 72)
    print("Local: " + LOCAL_BASE)
    print("Remote: " + REMOTE_BASE)
    print("Options: " + LOCAL_BASE + "api/options")
    print("Backend Settings: " + BACKEND_SETTINGS_URL)
    print("Identity state: " + str(STATE_IDENTITY_FILE))
    print("Backends state: " + str(STATE_BACKENDS_FILE))
    print()
    with Server((LOCAL_BIND, LOCAL_PORT), Handler) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        print("Server running. Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Stopping server.")
            server.shutdown()


if __name__ == "__main__":
    main()
