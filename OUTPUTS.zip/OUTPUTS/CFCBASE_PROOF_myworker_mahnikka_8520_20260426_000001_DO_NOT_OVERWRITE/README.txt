Standalone CFCBASE proof output.

This folder is intentionally unique and append-only.
Do not overwrite it. Do not delete it.

Remote replacement for openclaude.111724.xyz:
https://myworker.mahnikka.workers.dev/

Local replacement for localhost:8787:
http://localhost:8520/

No robocopy. No mirror. No overwrite.
