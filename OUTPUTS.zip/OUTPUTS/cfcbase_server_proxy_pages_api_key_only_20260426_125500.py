#!/usr/bin/env python3
"""
Standalone CFCBASE wrapper.

Fixes the previous wrapper's overly broad uiNodes.

Backend Settings belongs on the API-key/config surface only.
It must not replace sidepanel login, sign-in, beta, or risk-warning UI.

No existing files are edited.
No request.js changes.
"""

import importlib.util
from pathlib import Path


BASE_WRAPPER = (
    Path(__file__).resolve().parent
    / "cfcbase_server_proxy_pages_from_12py_20260426_124457.py"
)

spec = importlib.util.spec_from_file_location("cfcbase_server_proxy_pages_from_12py", BASE_WRAPPER)
wrapped = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wrapped)


def api_key_only_ui_nodes():
    link = {
        "type": "a",
        "props": {
            "href": wrapped.cfc.BACKEND_SETTINGS_URL,
            "target": "_blank",
            "rel": "noreferrer",
            "children": "Backend Settings",
        },
    }
    labels = [
        "API Key",
        "Api Key",
        "API key",
        "Enter API Key",
        "Set API Key",
        "Set API key",
        "Manage API Key",
        "Manage API key",
        "Configure API",
        "API Configuration",
    ]
    nodes = []
    for label in labels:
        nodes.append({"selector": {"type": "button", "props": {"children": label}}, "replace": link})
        nodes.append({"selector": {"type": "a", "props": {"children": label}}, "replace": link})
    return nodes


wrapped.cfc.safe_ui_nodes = api_key_only_ui_nodes


if __name__ == "__main__":
    wrapped.cfc.main()
